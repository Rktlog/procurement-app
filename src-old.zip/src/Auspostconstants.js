// Shared AusPost constants and helpers -- used by Cin7Fulfillment.jsx
// (Tabs 6/7, the CSV export path) and by the per-tab components
// (AusPostValidateTab.jsx, etc.). Kept in its own file specifically so
// neither the main file nor a tab component needs to import from the
// other just to reach these -- avoids a circular dependency.

// Fixed per-business settings for international shipments. Same values
// already used in this account's existing working implementation.
export const INTL_SENDER_BUSINESS = 'Rocket Logistics';
export const INTL_SENDER_EMAIL = 'logistics@rocketlog.com.au';
export const INTL_PRODUCT_ID = 'PTI7';

// Confirmed via AusPost's real, complete documentation: the A6 layout
// value is genuinely different per product family. Parcel Post,
// Express Post, International, and International Commercial all use
// "THERMAL-LABEL-A6-1PP" -- the plain "A6-1pp"/"A6-1PP" naming is only
// valid for StarTrack, StarTrack Courier, and On Demand, a different
// product family entirely. The earlier "A6-1pp" value was wrong for
// our actual products (3D55/3J55/PTI7, all Parcel Post/Express Post/
// International) -- AusPost silently falling back to a different,
// much longer format instead of erroring is what "the express post
// label seems too long" was actually describing.
export const LABEL_LAYOUT_A6 = 'THERMAL-LABEL-A6-1PP';
export const LABEL_LAYOUT_A4 = 'A4-1pp';
export const INTL_REASON_FOR_EXPORT = 'Commercial Sale of Goods (B2B)';
export const INTL_ITEM_ORIGIN = 'US';
export const INTL_ITEM_DESCRIPTION = 'Pantone Color Guide Book';
export const INTL_ITEM_HS_CODE = '9609100919';

// Confirmed real registered business address (Get Accounts, production
// account 0005303796) -- used as the "from" for every AusPost address
// validation, pricing check, and shipment creation.
export const SENDER_ADDRESS = {
  // Real, confirmed registered business name and street address from
  // tonight's actual production Get Accounts response for account
  // 0005303796. Both were missing entirely before -- Get Shipment
  // Price didn't need them (pricing doesn't care who's sending or
  // their exact street address), but Create Shipment requires both,
  // which is why shipment creation kept failing one missing-field
  // error at a time while pricing worked fine using this same object.
  name: 'Rocket Logistics Australia Pty Ltd',
  lines: ['26-28 Scammel St'],
  suburb: 'CAMPBELLFIELD',
  state: 'VIC',
  postcode: '3061',
  // Real confirmed email from tonight's Get Accounts response. Phone
  // is a placeholder (no real one was ever returned by Get Accounts to
  // confirm) -- worth replacing with the business's actual number if
  // AusPost ever rejects this specific value.
  email: 'ops@seaga.com.au',
  phone: '0394509500',
};

export const COUNTRY_CODE_MAP = {
  'NEW ZEALAND': 'NZ', 'NZ': 'NZ',
  'AUSTRALIA': 'AU', 'AU': 'AU',
  'UNITED STATES': 'US', 'USA': 'US', 'UNITED STATES OF AMERICA': 'US',
  'UNITED KINGDOM': 'GB', 'UK': 'GB', 'GREAT BRITAIN': 'GB', 'ENGLAND': 'GB', 'SCOTLAND': 'GB', 'WALES': 'GB',
  'CANADA': 'CA', 'SINGAPORE': 'SG', 'HONG KONG': 'HK', 'CHINA': 'CN', 'JAPAN': 'JP',
  'SOUTH KOREA': 'KR', 'KOREA': 'KR', 'TAIWAN': 'TW', 'MALAYSIA': 'MY', 'INDONESIA': 'ID',
  'THAILAND': 'TH', 'PHILIPPINES': 'PH', 'VIETNAM': 'VN', 'INDIA': 'IN', 'FIJI': 'FJ',
  'PAPUA NEW GUINEA': 'PG', 'GERMANY': 'DE', 'FRANCE': 'FR', 'ITALY': 'IT', 'SPAIN': 'ES',
  'NETHERLANDS': 'NL', 'IRELAND': 'IE', 'UNITED ARAB EMIRATES': 'AE', 'UAE': 'AE',
};

// AusPost's international template wants a country CODE, not a full name.
export function normaliseCountryCode(rawCountry) {
  const key = (rawCountry || '').trim().toUpperCase();
  if (COUNTRY_CODE_MAP[key]) return COUNTRY_CODE_MAP[key];
  if (!key) return 'NZ'; // default destination for these shipments
  if (key.length === 2) return key; // already looks like a code
  return rawCountry;
}

// AusPost's real, confirmed field limits (from the Create Shipment /
// Get Shipment Price field reference): name and business_name are each
// capped at 40 characters; the first address line is capped at 40, the
// second address line explicitly documented as accepting up to 60.
// Third line assumed to follow the second line's limit, since AusPost's
// docs describe lines 2/3 as a matching pair distinct from line 1.
export const AUSPOST_NAME_MAX = 40;
export const AUSPOST_ADDRESS_LINE1_MAX = 40;
export const AUSPOST_ADDRESS_LINE_OTHER_MAX = 60;

// Hard truncation for name/business_name fields -- AusPost has no
// concept of "continue on another field" for these the way it does for
// addresses, so this is a plain cut to the limit.
export function truncateField(value, maxLen = AUSPOST_NAME_MAX) {
  const s = (value || '').toString().trim();
  return s.length > maxLen ? s.slice(0, maxLen).trimEnd() : s;
}

// Splits a full address string into up to 3 AusPost address lines,
// respecting each line's real character limit. Breaks on word
// boundaries (spaces) so a word is never cut in half across lines --
// only falls back to a hard mid-word cut if a single word alone still
// exceeds a line's limit, which real address data essentially never
// hits. Any overflow beyond what 3 lines can hold is dropped, since
// AusPost's own address type caps out at three lines.
export function buildAddressLines(fullAddress) {
  const words = (fullAddress || '').toString().trim().split(/\s+/).filter(Boolean);
  const limits = [AUSPOST_ADDRESS_LINE1_MAX, AUSPOST_ADDRESS_LINE_OTHER_MAX, AUSPOST_ADDRESS_LINE_OTHER_MAX];
  const lines = [];
  let current = '';
  let lineIndex = 0;

  for (const word of words) {
    if (lineIndex >= 3) break; // out of lines -- real overflow, dropped

    const limit = limits[lineIndex];
    const candidate = current ? `${current} ${word}` : word;

    if (candidate.length <= limit) {
      current = candidate;
      continue;
    }

    // Doesn't fit on the current line -- close it out and start the
    // next one, unless this single word alone is longer than an entire
    // line's limit (rare), in which case hard-cut it rather than push
    // it whole onto a line it can never fit.
    if (current) {
      lines.push(current);
      lineIndex += 1;
      current = '';
    }
    if (lineIndex >= 3) break;

    if (word.length > limits[lineIndex]) {
      lines.push(word.slice(0, limits[lineIndex]));
      lineIndex += 1;
      current = '';
    } else {
      current = word;
    }
  }
  if (current && lineIndex < 3) lines.push(current);

  return lines.filter(Boolean);
}

// ===================================================================
// International customs declaration
// ===================================================================
// Every international parcel needs a customs declaration on the item:
// what it is (item_description), why it's being sent
// (classification_type + commercial_value) and one item_contents row per
// product in the box. Domestic parcels never get any of this.
//
// contents: [{ sku, description, quantity, unitValue, unitWeight }]
// unitValue is the AUD sale price of ONE unit, unitWeight is kg per unit.
//
// Returns { item } or { error } -- errors are plain-English and say how
// to fix the order, so they can go straight into the Label Status column.
const AUSPOST_CONTENT_DESCRIPTION_MAX = 40;
// Australian export rule: goods over AUD 2,000 per consignment need an
// Export Declaration Number, which this app doesn't collect.
const EXPORT_DECLARATION_THRESHOLD_AUD = 2000;

export function buildInternationalItem({ reference, entry, contents }) {
  const usable = (contents || []).filter((c) => Number(c.quantity) > 0);
  if (usable.length === 0) {
    return { error: 'International label needs the products in the box for the customs form, but this order has no packed lines.' };
  }
  const missingValue = usable.filter((c) => !(Number(c.unitValue) > 0));
  if (missingValue.length > 0) {
    return {
      error: `Customs form needs a sale price for every product. Missing for: ${missingValue.map((c) => c.sku || c.description).join(', ')}.`,
    };
  }

  const itemContents = usable.map((c) => ({
    description: truncateField(c.description || c.sku || INTL_ITEM_DESCRIPTION, AUSPOST_CONTENT_DESCRIPTION_MAX),
    ...(c.sku ? { sku: truncateField(c.sku, AUSPOST_CONTENT_DESCRIPTION_MAX) } : {}),
    quantity: Math.max(1, Math.round(Number(c.quantity))),
    value: Number(Number(c.unitValue).toFixed(2)),
    weight: Number(Math.max(0.001, Number(c.unitWeight) || 0.2).toFixed(3)),
    tariff_code: INTL_ITEM_HS_CODE,
    country_of_origin: INTL_ITEM_ORIGIN,
  }));

  const declaredTotal = itemContents.reduce((sum, c) => sum + c.value * c.quantity, 0);
  if (declaredTotal > EXPORT_DECLARATION_THRESHOLD_AUD) {
    return {
      error: `Declared value is $${declaredTotal.toFixed(2)} AUD, over the $2,000 limit. This parcel needs an Export Declaration Number, so book it directly in AusPost.`,
    };
  }

  return {
    item: {
      item_reference: reference,
      product_id: entry.service,
      length: String(entry.length),
      width: String(entry.width),
      height: String(entry.height),
      weight: String(entry.weight),
      item_description: truncateField(INTL_ITEM_DESCRIPTION, AUSPOST_CONTENT_DESCRIPTION_MAX),
      classification_type: 'SALE_OF_GOODS',
      commercial_value: true,
      item_contents: itemContents,
    },
  };
}

// Checks the destination fields AusPost needs for an international
// parcel that a domestic one can live without. Returns an error string
// or null.
export function checkInternationalTo(to) {
  if (!/^[A-Z]{2}$/.test(to.country || '')) {
    return `Country "${to.country || 'blank'}" isn't a 2-letter country code. Fix it with Edit address (for example NZ, US, GB).`;
  }
  if (to.country === 'AU') {
    return 'Country is Australia but the service is International. Change the service to Parcel Post or Express Post, or fix the country with Edit address.';
  }
  if (!(to.phone || '').trim()) {
    return "International labels need the customer's phone number. Add it with Edit address.";
  }
  if (!(to.lines || []).some((l) => (l || '').trim())) {
    return 'Street address is empty. Add it with Edit address.';
  }
  return null;
}

// International parcels also carry the sender's country.
export const SENDER_ADDRESS_INTL = { ...SENDER_ADDRESS, country: 'AU' };
